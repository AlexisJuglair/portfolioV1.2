# Challenge Playstation Pad Logo réalisé en formation chez Onlineformapro en 2021.
