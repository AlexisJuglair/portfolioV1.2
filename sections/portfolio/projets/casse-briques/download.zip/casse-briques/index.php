<html>
    <head>
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
		<meta http-equiv="Pragma" content="no-cache" />
		<meta http-equiv="Expires" content="0" />
		<link href="styles.css" rel="stylesheet" />
		<link rel="icon" type="image/png" href="favicon.png" />
		<script type="text/javascript" src="jeu.js"></script>
		<script type="text/javascript" src="arene.js"></script>
		<script type="text/javascript" src="brique.js"></script>
		<script type="text/javascript" src="mur.js"></script>
		<script type="text/javascript" src="batte.js"></script>
		<script type="text/javascript" src="balle.js"></script>
		<script type="text/javascript" src="point.js"></script>
		<script type="text/javascript" src="code.js"></script>		
    </head>
    <body id="body">
		<script>
			init();
		</script>
    </body>
</html>