<?php

define("MYSQL_HOST", "mysql.xiong.fr");
define("MYSQL_PORT", "3306");
define("MYSQL_DB",   "dsm");
define("MYSQL_USER", "dsm");
define("MYSQL_PWD",  "dsm146");
