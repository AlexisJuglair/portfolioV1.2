<?php

define("DEBUG", TRUE);

print("<h1>dsm</h1>");

require_once("config.php");
require_once("common.php");
require_once("models/model.php");
require_once("views/view.php");

