dsm.models =
{
    session: {},
    login: {},
    lists: {},
    forms: {}
}