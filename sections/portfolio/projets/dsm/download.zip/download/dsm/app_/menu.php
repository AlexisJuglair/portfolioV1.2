

            <ul>
                <li>Accueil</li>
                <li>Personnes
                    <ul>
                        <li onclick="dsm.controlers.lists.openForm('adherents');">Adhérents</li>
                        <li onclick="dsm.controlers.lists.openForm('eleves');">Elèves</li>
                        <separator></separator>
                        <li onclick="dsm.controlers.lists.openForm('professeurs');">Professeurs</li>
                        <li onclick="dsm.controlers.lists.openForm('benevoles');">Bénévoles</li>
                        <li>Bureau</li>
                        <separator></separator>
                        <li>Fournisseurs</li>
                        <li>Clients</li>
                        <li>Structure</li>
                    </ul>
                </li>
                <li>Cours
                    <ul>
                        <li>Saisons</li>
                        <li>Plannings hebdomadaires</li>
                        <separator></separator>
                        <li>Disciplines</li>
                        <li>Niveaux</li>
                        <li>Professeurs</li>
                        <li>Salles</li>
                    </ul>
                </li>
                <li>Evènements
                    <ul>
                        <li>Stages</li>
                        <li>Parties dansantes</li>
                    </ul>
                </li>
                <li>Produits
                    <ul>
                        <li>Catégories</li>
                        <li>Produits</li>
                        <separator></separator>
                        <li>Fournisseurs</li>
                        <li>Clients</li>
                    </ul>
                </li>
                <li>Budget
                    <ul>
                        <li>Achats</li>
                        <li>Ventes</li>
                    </ul>
                </li>
                <li>Mon compte 
                    <ul>
                        <li>Gérer mon compte</li>
                        <li onclick="dsm.controlers.session.logout();">Déconnexion</li>
                    </ul>
                </li>
            </ul>