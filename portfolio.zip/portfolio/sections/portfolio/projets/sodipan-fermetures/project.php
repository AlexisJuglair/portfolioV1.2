<div class="col">
    <div class="portfolio-card">
        <img src="sections/portfolio/projets/sodipan-fermetures/screen.png" alt="sodipan-fermetures">
        <div>
            <h5>Sodipan Fermetures</h5>
            <p>Reprise du site Sodipan Fermetures sous Wordpress avec un nouveau thème.</p>
            <a class="btn" href="https://www.sodipan-fermetures.fr/" target="_blank">
                <i class="fas fa-eye"></i>
                Voir
            </a>
        </div>
    </div>
</div>