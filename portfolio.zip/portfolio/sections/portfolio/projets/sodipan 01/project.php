<div class="col">
    <div class="portfolio-card">
        <img src="sections/portfolio/projets/sodipan 01/screen.png" alt="sodipan01">
        <div>
            <h5>Sodipan 01</h5>
            <p>Reprise du site Sodipan 01 sous Wordpress avec un nouveau thème.</p>
            <a class="btn" href="https://www.sodipan01.fr/" target="_blank">
                <i class="fas fa-eye"></i>
                Voir
            </a>
        </div>
    </div>
</div>