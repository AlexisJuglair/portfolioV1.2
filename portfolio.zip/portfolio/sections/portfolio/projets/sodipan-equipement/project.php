<div class="col">
    <div class="portfolio-card">
        <img src="sections/portfolio/projets/sodipan-equipement/screen.png" alt="sodipan-equipement">
        <div>
            <h5>Sodipan Equipement</h5>
            <p>Reprise du site Sodipan Equipement sous Wordpress (précédemment sous Prestashop) avec un nouveau thème.</p>
            <a class="btn" href="https://www.sodipan-equipement.fr/" target="_blank">
                <i class="fas fa-eye"></i>
                Voir
            </a>
        </div>
    </div>
</div>