<div class="col">
    <div class="portfolio-card">
        <img src="sections/portfolio/projets/symshop/screen.png" alt="symshop">
        <div>
            <h5>Tutoriel site e-commerce SymShop</h5>
            <p>Réalisation d'un tutoriel de site e-commerce avec Symfony et Bootstrap.</p>
            <a class="btn">
                <i class="fas fa-eye"></i>
                Voir
            </a>
        </div>
    </div>
</div>