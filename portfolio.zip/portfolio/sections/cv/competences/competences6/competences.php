<li>
    <a href="https://www.adobe.com/fr/products/photoshop/landpb.html" target="_blank"><img src="sections/cv/competences/competences6/photoshop.png" alt="photoshop" title="Photoshop"></a>
    <a href="https://www.microsoft.com/fr-fr/windows/" target="_blank"><img src="sections/cv/competences/competences6/windows.png" alt="windows" title="Windows"></a>
    <a href="https://ubuntu.com/" target="_blank"><img src="sections/cv/competences/competences6/ubuntu.png" alt="ubuntu"title="Ubuntu"></a>
</li>