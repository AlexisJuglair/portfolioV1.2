<li>					
    <a href="https://symfony.com/" target="_blank"><img src="sections/cv/competences/competences4/symfony.png" alt="symfony" title="Symfony"></a>
    <a href="https://fr.wordpress.org/" target="_blank"><img src="sections/cv/competences/competences4/wordpress.png" alt="wordpress" title="WordPress"></a>										
    <a href="https://www.prestashop.com/fr/" target="_blank"><img src="sections/cv/competences/competences4/prestashop.png" alt="prestashop" title="PrestaShop"></a>
</li>