<li>  											
    <a href="https://laragon.org/" target="_blank"><img src="sections/cv/competences/competences5/laragon.png" alt="laragon" title="Laragon"></a>
    <a href="https://code.visualstudio.com/" target="_blank"><img src="sections/cv/competences/competences5/vscode.png" alt="visualstudiocode" title="Visual Studio Code"></a>
    <a href="https://filezilla-project.org/" target="_blank"><img src="sections/cv/competences/competences5/filezilla.png" alt="filezilla" title="FileZilla"></a>
</li>