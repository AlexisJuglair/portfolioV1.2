<li>
    <a href="https://getbootstrap.com/" target="_blank"><img src="sections/cv/competences/competences3/bootstrap.png" alt="bootstrap" title="Bootstrap"></a>
    <a href="https://jquery.com/" target="_blank"><img src="sections/cv/competences/competences3/jquery.png" alt="jquery" title="jQuery"></a>
    <a href="https://fr.reactjs.org/" target="_blank"><img src="sections/cv/competences/competences3/react.png" alt="react" title="React"></a>
</li>