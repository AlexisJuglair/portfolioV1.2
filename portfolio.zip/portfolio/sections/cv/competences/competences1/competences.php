<li>
    <a href="https://html.spec.whatwg.org/multipage/" target="_blank"><img src="sections/cv/competences/competences1/html5.png" alt="html5" title="HTML5"></a>
    <a href="https://www.w3.org/Style/CSS/" target="_blank"><img src="sections/cv/competences/competences1/css3.png" alt="css3" title="CSS3"></a>
    <a href="https://developer.mozilla.org/fr/docs/Web/JavaScript/" target="_blank" class="mx-2"><img src="sections/cv/competences/competences1/javascript.png" alt="javascript" title="JavaScript"></a>
</li>