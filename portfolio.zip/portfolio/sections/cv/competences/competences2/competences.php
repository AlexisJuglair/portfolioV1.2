<li>
    <a href="https://www.php.net/" target="_blank"><img src="sections/cv/competences/competences2/php.png" alt="php" title="PHP"></a>
    <a href="https://www.mysql.com/" target="_blank"><img src="sections/cv/competences/competences2/mysql.png" alt="mysql" title="MySQL"></a>
    <a href="https://git-scm.com/" target="_blank"><img src="sections/cv/competences/competences2/git.png" alt="git" title="Git"></a>
</li>