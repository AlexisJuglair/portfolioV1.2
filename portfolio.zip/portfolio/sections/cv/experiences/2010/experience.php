<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="#">
            <img src="sections/cv/experiences/2010/logo.png" alt="6cinfo">
            <h4>6C Info</h4>
        </a>
        <span>2010</span>
        <h5>Stagiaire technicien informatique</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Installation de système d'exploitation, changement de pièces défectueuses, transfert de données, installation de CPL, installation de logiciels.</p>
    </div>
</div>