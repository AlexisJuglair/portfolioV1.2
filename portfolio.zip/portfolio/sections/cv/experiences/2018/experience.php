<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="https://www.sodipan01.fr/" target="_blank">
            <img src="sections/cv/experiences/2018/logo.png" alt="sodipan">
            <h4>Sodipan</h4>
        </a>
        <span>2018</span>
        <h5>Développeur web</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Développement des trois sites web de l'entreprise sous Wordpress, référencement, formation utilisateur, rédaction de la documentation, mise en ligne de produits.</p>
    </div>
</div>