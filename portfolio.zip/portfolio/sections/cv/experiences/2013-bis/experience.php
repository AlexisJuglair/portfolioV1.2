<div class="resume-work-item">
    <div class="resume-work-item-heading">
    <a href="https://www.nexans.fr/fr/" target="_blank">
        <img src="sections/cv/experiences/2013-bis/logo.png" alt="nexans">
        <h4>Nexans</h4>
    </a>
    <span>2013</span>
    <h5>Développeur</h5>
    </div>
    <div class="resume-work-item-content">
    <p>Suite et fin du développement d'une application de gestion de lignes de production (VB.net avec SGBD Access).</p>
    </div>
</div>