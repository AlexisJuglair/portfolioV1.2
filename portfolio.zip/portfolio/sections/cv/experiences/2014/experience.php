<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="https://www.g-p-i.fr/" target="_blank">
            <img src="sections/cv/experiences/2014/logo.png" alt="gpi">
            <h4>GPI</h4>
        </a>
        <span>2014</span>
        <h5>Développeur</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Maintenance et correction de bugs sur les programmes du progiciel de transport D'Artagnan (Progress).</p>
    </div>
</div>