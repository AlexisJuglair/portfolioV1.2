<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="https://www.ellipseinfo.com/" target="_blank">
            <img src="sections/cv/experiences/2010-bis/logo.png" alt="ellipse">
            <h4>Ellipse Informatique</h4>
        </a>
        <span>2010</span>
        <h5>Stagiaire technicien informatique</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Montage unité centrale, (ré)installation de système d'exploitation, changement de pièces défectueuses, transfert de données.</p>
    </div>
</div>