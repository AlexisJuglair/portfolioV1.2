
<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="http://www.2bsystem.fr/" target="_blank">
            <img src="sections/cv/experiences/2020/logo.png" alt="2bsystem">
            <h4>2BSystem</h4>
        </a>
        <span>2020</span>
        <h5>Développeur web</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Développement d'un portail web pour les clients des clients dans le domaine de l'agroalimentaire (J2EE, Bulma).</p>
    </div>
</div>