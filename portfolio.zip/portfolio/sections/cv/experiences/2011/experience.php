<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="http://www.ain.gouv.fr/" target="_blank">
            <img src="sections/cv/experiences/2011/logo.png" alt="prefecture-ain">
            <h4>Préfecture de l'Ain</h4>
        </a>
        <span>2011</span>
        <h5>Stagiaire technicien informatique</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Développement d'un script de sauvegarde (AutoIt), remplacement de matériel, prise en main à distance (VMware).</p>
    </div>
</div>