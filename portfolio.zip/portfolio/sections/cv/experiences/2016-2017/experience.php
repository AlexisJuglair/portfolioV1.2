<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="https://www.reseau-canope.fr/academie-de-lyon/atelier-canope-01-bourg-en-bresse.html" target="_blank">
            <img src="sections/cv/experiences/2016-2017/logo.png" alt="reseau-canope">
            <h4>Réseau Canopé</h4>
        </a>
        <span>2016-2017</span>
        <h5>Technicien/développeur informatique</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Gestion des postes/du matériel informatiques/tablettes iPad-Android, développement d'une application web degestion de storyboard (HTML, CSS, PHP, JavaScript, jQuery), réalisation de web documentaires (Klynt).</p>
    </div>
</div>