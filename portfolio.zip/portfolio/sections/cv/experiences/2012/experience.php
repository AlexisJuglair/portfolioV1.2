<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="http://erea71-claudebrosse.ac-dijon.fr/" target="_blank">
            <img src="sections/cv/experiences/2012/logo.png" alt="erea">
            <h4>EREA</h4>
        </a>
        <span>2012</span>
        <h5>Développeur</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Développement d'une application de gestion des stocks (VB.net avec SGBD Access).</p>
    </div>
</div>