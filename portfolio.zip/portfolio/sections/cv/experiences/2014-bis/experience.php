<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="https://www.ameli.fr/assure/adresses-et-contact/points-accueil/agence-de-macon/" target="_blank">
            <img src="sections/cv/experiences/2014-bis/logo.png" alt="cpam">
            <h4>CPAM</h4>
        </a>
        <span>2014</span>
        <h5>Technicien informatique</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Gestion de requête, mise en forme de tableaux de résultats et formation publipostage.</p>
    </div>
</div>