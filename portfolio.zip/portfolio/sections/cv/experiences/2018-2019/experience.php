<div class="resume-work-item">
    <div class="resume-work-item-heading">
        <a href="http://www.acg-synergies.fr/" target="_blank">
            <img src="sections/cv/experiences/2018-2019/logo.png" alt="acg-synergies">
            <h4>ACG Synergies</h4>
        </a>
        <span>2018-2019</span>
        <h5>Développeur</h5>
    </div>
    <div class="resume-work-item-content">
        <p>Développement de projet et correction de bugs sur le progiciel de logement social Aravis (Plex, AS400, Scrum).</p>
    </div>
</div>