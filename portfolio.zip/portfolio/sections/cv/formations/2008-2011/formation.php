<li>
    <div>BAC professionnel Systèmes Electroniques Numériques</div>
    <div class="aside-education-organization">Lycée Saint Joseph de Bourg-en-Bresse</div>
    <div class="aside-education-years">2008 - 2011</div>
</li>