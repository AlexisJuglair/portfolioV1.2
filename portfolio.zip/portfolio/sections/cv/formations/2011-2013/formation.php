<li>
    <div>BTS Systèmes Informatiques aux Organisations option Développement</div>
    <div class="aside-education-organization">Lycée Lamartine de Mâcon</div>
    <div class="aside-education-years">2011 - 2013</div>
</li>