
<li>
    <div>Titre professionnel niveau 5 Développeur Web et Web Mobile </div>
    <div class="aside-education-organization">Onlineformapro</div>
    <div class="aside-education-years">2021 - 2022</div>
</li>